package csvtest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class inOutFunction {

	private String url="jdbc:sqlserver://localhost:1433;databaseName=mis";
	private String user="Dukelo";
	private String password="manager";
	
	public void inputFile() throws IOException {
	    String inputLine;
	    String outputLine;
	    String[] temp = null;	    
	    int count=0;
	    
	    URL ul = new URL("https://data.tainan.gov.tw/dataset/"
	    		+ "710b46b9-a1d0-4f90-8299-d7bd2cdd3ad4/resource/"
	    		+ "acb7f912-4bc4-4b59-931a-b4c7b0b2be1d/download/01_schoolopentime.csv");
	    	    
	    /*宣告輸入需要Download的網址(CSV)與設定的Table名稱*/
//		String webSite=JOptionPane.showInputDialog("請輸入網址"); //download不同欄數table
//		String tableName=JOptionPane.showInputDialog("請輸入Title");	//download不同欄數table
//		URL ul=new URL(webSite); //download不同欄數table

	    String tableName="tableName";//測試用,資料固定以tableName命名
		InputStreamReader in=new InputStreamReader(ul.openStream());
		BufferedReader bin = new BufferedReader(in);
			
		FileWriter fw=new FileWriter("C:\\Java\\workspace\\Project1\\csvtest\\"+tableName+".txt"); //download不同欄數table
		FileReader fr=new FileReader("C:\\Java\\workspace\\Project1\\csvtest\\"+tableName+".txt"); //download不同欄數table

		BufferedReader bfr=new BufferedReader(fr);
				
		/*將CSV寫入暫存檔並記錄資料筆數與計算欄數*/
		while ((inputLine = bin.readLine()) != null) {
        	temp=inputLine.split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)");
        	count++;
        	fw.write(inputLine);
        	fw.write("\r\n");
        }
        in.close();
        bin.close();
		fw.close();
        
		/*使用2維陣列儲存資料(包含欄位定義)並給予id*/
        String[][] data=new String[count][temp.length+1];
        for(int i=0;i<count;i++) {
        	outputLine=bfr.readLine();
        	temp=outputLine.split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)");
        	data[i][0]=Integer.toString(i);
	        for(int j=0;j<temp.length;j++) {
	        	data[i][j+1]=temp[j];
	        }
        }
        
        fr.close();
        bfr.close();
                
		/*處理data[0][1]字串,將多餘空格切除*/        
        String data01String;
        data01String=data[0][1].substring(1);
        data[0][1]=data01String;
                
        /*字串組合-建立表頭 for sql*/
        String strTitle="id varchar(200),";
        for(int i=1;i<temp.length+1;i++) {
        	if(data[0][i].contains("[")||data[0][i].contains("-")){
        		data[0][i]="\""+data[0][i]+"\"";
        	}
        	if(i==temp.length) {
        		strTitle=strTitle+data[0][i]+" varchar(200)";
        	}else {
        		strTitle=strTitle+data[0][i]+" varchar(200),";	
        	}
        }
        strTitle="("+strTitle+")";
//        System.out.println(strTitle);
		String sqlTitle="Create table "+tableName+strTitle;
		System.out.println("sqlTitle= "+sqlTitle);
		 
		/*字串組合-建立內容使用陣列儲存  for sql*/		
		String strContext=""; //給字串初始值
		String[] sqlContext=new String[count-1];
		for(int i=1;i<count;i++) {
			for(int j=0;j<=temp.length;j++) {
				if(j==temp.length) {
					strContext=strContext+"'"+data[i][j]+"'";
				}else {
					strContext=strContext+"'"+data[i][j]+"'"+",";
				}		
			}	
			sqlContext[i-1]="insert into "+tableName+" values("+strContext+")";
			strContext="";
		}
		for(int i=0;i<count-1;i++) {
			System.out.println("sqlContext= "+sqlContext[i]);
		}
		
		/*建立連線*/
        try(Connection conn=DriverManager.getConnection(url, user, password)) {
        	System.out.println("連線成功");
			Statement stmtTitle=conn.createStatement();
			stmtTitle.executeUpdate(sqlTitle); //在資料庫建立表頭
			Statement stmtContext=conn.createStatement();
			for(int i=0;i<=count-2;i++) {
				stmtContext.execute(sqlContext[i]);
			}	
			
		} catch (SQLException e) {
			System.out.println("連線失敗");
			e.printStackTrace();
		}
	}
	
	public void outputfile() {
		
		String tableNamew="";
    	tableNamew=JOptionPane.showInputDialog(null,"請輸入Output file名稱","名稱",
    			JOptionPane.PLAIN_MESSAGE);
		
		try {
			/*建立output file*/
			FileWriter fw=new FileWriter("C:\\Java\\workspace\\Project1\\csvtest\\"+tableNamew+".txt");
			BufferedWriter bfw=new BufferedWriter(fw);
			
			/*連線資料庫,取得output資料*/
			sqlFunction sql=new sqlFunction();
			String output[][]=sql.select("tableName");
			
			/*資料後處理*/
			String outputSelect[]=new String[output.length];
			String str="";
			for(int i=0;i<output.length;i++) {
				for(int j=0;j<output[0].length;j++) {
					str=str+"\""+output[i][j]+"\""+",";
				}
				str=str.substring(0,str.length()-1);
				outputSelect[i]=str;
				str="";
			}
			System.out.println("寫入"+tableNamew);
			for(int i=0;i<output.length;i++) {
				System.out.println("output="+outputSelect[i]);
			}
			
			/*寫入output file*/
			for(int i=0;i<output.length;i++) {
				bfw.write(outputSelect[i]);
				bfw.newLine();
			}
			bfw.flush();
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void outputfile(String outputTable[][]) throws IOException {
		
	    String tableNamew="";
    	tableNamew=JOptionPane.showInputDialog(null,"請輸入Output file名稱","名稱",
    			JOptionPane.PLAIN_MESSAGE);
		
		/*建立output file*/
		FileWriter fw=new FileWriter("C:\\Java\\workspace\\Project1\\csvtest\\"+tableNamew+".txt");
		BufferedWriter bfw=new BufferedWriter(fw);
    	
		String output[][];
		output=outputTable;
		
		/*資料後處理*/
		String outputSelect[]=new String[output.length];
		String str="";
		for(int i=0;i<output.length;i++) {
			for(int j=0;j<output[0].length;j++) {
				str=str+"\""+output[i][j]+"\""+",";
			}
			str=str.substring(0,str.length()-1);
			outputSelect[i]=str;
			str="";
		}
		System.out.println("寫入"+tableNamew);
		for(int i=0;i<output.length;i++) {
			System.out.println("output="+outputSelect[i]);
		}
		
		/*寫入output file*/
		for(int i=0;i<output.length;i++) {
			bfw.write(outputSelect[i]);
			bfw.newLine();
		}
		bfw.flush();
		fw.close();
	}
}
