package csvtest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class sqlFunctionV1 {
	private String url="jdbc:sqlserver://localhost:1433;databaseName=mis";
	private String user="Dukelo";
	private String password="manager";

	public String[][] select(String tableName){
	    String select[][] = null;		
		Connection conn=null;
		
		try {
			conn=DriverManager.getConnection(url, user, password);
        	String tableCount="select count(*) from "+tableName;
        	String sql="select * from "+tableName;
        	System.out.println("連線成功");
        	PreparedStatement stmtcount=conn.prepareStatement(tableCount);
        	PreparedStatement stmt=conn.prepareStatement(sql);
        	ResultSet rscount=stmtcount.executeQuery();
        	ResultSet rs=stmt.executeQuery();
        	ResultSetMetaData rsmd=rs.getMetaData();
			
        	/*取得總筆數*/
        	rscount.next();
        	int count=rscount.getInt(1);
        	
        	/*取得欄位數量與欄位名稱*/
        	String getSelect[][] = new String[count+1][rsmd.getColumnCount()];
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getSelect[0][i]=rsmd.getColumnName(i+1);			
        	}
        	
        	/*匯入資料*/
        	int k=1;
        	while(rs.next()) {
        		for(int j=0;j<rsmd.getColumnCount();j++) {
            		getSelect[k][j]=rs.getString(j+1);			
            	}
        		k++;
        	}        	
        	
        	for(int i=0; i<count+1;i++) {
        		System.out.println();
        		for(int j=0;j<rsmd.getColumnCount();j++) {
        			System.out.print(getSelect[i][j]+","+"\t");
        		}
        	}
        	select=getSelect;/*以2維陣列回傳資料*/
        	conn.close();
        	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if (conn != null) {
					if (!conn.isClosed()) {
						conn.close();
					}
				}
			} catch (Exception e2) {
			}
		}		
		return select;
	}
	
	public String[][] selectBy(String tableName){
		String selectBy[][]=null;
		Connection conn=null;
		
		try {
			conn=DriverManager.getConnection(url, user, password);
        	String sql="select * from "+tableName;
        	String sqlcount="select count(*) from "+tableName;
        	String sqlSelectBy="";
        	System.out.println("連線成功");
        	PreparedStatement stmt=conn.prepareStatement(sql);
        	ResultSet rs=stmt.executeQuery();
        	ResultSetMetaData rsmd=rs.getMetaData();
			        	
        	/*取得欄位數量與欄位名稱*/
        	String getAllName[]=new String[rsmd.getColumnCount()+1];
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getAllName[i]=rsmd.getColumnName(i+1);
        	}
        	getAllName[rsmd.getColumnCount()]="end";
        	
        	/*取得查詢資料欄位*/
        	String selectName="";//查詢資料欄位
        	String str="";
        	
        	while(true) {
        		str=(String) JOptionPane.showInputDialog(null, "請輸入需求資料\n",
        				"需求資料",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        				getAllName,getAllName[0]);
        		if(str==getAllName[rsmd.getColumnCount()]) {
        			break;
        		}
        		selectName=selectName+"\""+str+"\""+",";
        	}
        	selectName=selectName.substring(0,selectName.length()-1);        	
			
        	/*取得查詢條件欄位*/
        	String whereSelect= (String) JOptionPane.showInputDialog(null, "請輸入查詢條件欄位",
        			"查詢欄位",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        			getAllName,getAllName[0]);
        	
        	/*進行查詢*/
        	String input=JOptionPane.showInputDialog(null,"請輸入查詢條件","查詢條件",
        			JOptionPane.PLAIN_MESSAGE);
        	sqlcount=sqlcount+" where "+whereSelect+"="+"'"+input+"'";
        	sqlSelectBy="select "+selectName+" from "+tableName+" where "+whereSelect+"="
        	            +"?"; 
        	System.out.println(sqlcount);
        	System.out.println(sqlSelectBy);
        	
        	PreparedStatement stmtcount=conn.prepareStatement(sqlcount);        	
        	PreparedStatement stmt1=conn.prepareStatement(sqlSelectBy);
        	ResultSet rscount=stmtcount.executeQuery();
        	stmt1.setString(1, input);
        	ResultSet rs1=stmt1.executeQuery();
        	ResultSetMetaData rsmd1=rs1.getMetaData();

        	/*取得查詢總筆數*/
        	rscount.next();
        	int count=rscount.getInt(1);
        	
        	/*取得欄位數量與欄位名稱*/
        	String getSelect[][] = new String[count+1][rsmd1.getColumnCount()];
        	for(int i=0;i<rsmd1.getColumnCount();i++) {
    		getSelect[0][i]=rsmd.getColumnName(i+1);			
        	}        	
        	
        	/*匯入資料*/
        	int k=1;
        	while(rs1.next()) {
        		for(int j=0;j<rsmd1.getColumnCount();j++) {
            		getSelect[k][j]=rs1.getString(j+1);			
            	}
        		k++;
        	}
        	for(int i=0; i<getSelect.length;i++) {
        		System.out.println();
        		for(int j=0;j<getSelect[1].length;j++) {
        			System.out.print(getSelect[i][j]+","+"\t");
        		}
        	}
        	selectBy=getSelect;
        	       	
        	conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (conn != null) {
					if (!conn.isClosed()) {
						conn.close();
					}
				}
			} catch (Exception e2) {
			}
		}		
		return selectBy;
	}
	
	public int insertData(String tableName) {
		int insertdatacount=0;
		Connection conn=null;
		
		try {
			conn=DriverManager.getConnection(url, user, password);
        	String sqlCount="select count(*) from "+tableName;
        	String sql="select * from "+tableName;
        	String sqlinsert="";
        	System.out.println("連線成功");
        	PreparedStatement stmtcount=conn.prepareStatement(sqlCount);
        	PreparedStatement stmt=conn.prepareStatement(sql);
        	ResultSet rscount=stmtcount.executeQuery();
        	ResultSet rs=stmt.executeQuery();
        	ResultSetMetaData rsmd=rs.getMetaData();
			
        	/*取得總筆數*/
        	rscount.next();
        	int count=rscount.getInt(1);
        	
        	/*取得欄位數量與欄位名稱*/
        	String getSelect[][] = new String[count+1][rsmd.getColumnCount()];
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getSelect[0][i]=rsmd.getColumnName(i+1);			
        	}
        	/*匯入資料*/
        	int k=1;
        	while(rs.next()) {
        		for(int j=0;j<rsmd.getColumnCount();j++) {
            		getSelect[k][j]=rs.getString(j+1);			
            	}
        		k++;
        	}        	
        	/*取得目前id最大值*/
        	int iidSelect[]=new int[count+1];
        	String sidSelect[]=new String[count+1];
        	for(int i=0;i<count;i++) {
        		sidSelect[i]=getSelect[i+1][0];
        	}        	
        	/*將id由字串轉成整數*/
        	for(int i=0;i<count;i++) {
        		iidSelect[i]=Integer.parseInt(sidSelect[i]);
        	}        	
        	/*取得id最大值*/
        	int idmax=iidSelect[0];
        	for(int i=0;i<count;i++) {
        		if(idmax<iidSelect[i]) {
        			idmax=iidSelect[i];
        		}	
        	}
        	
        	/*取得插入字串資料*/
        	String getAllName[][]=new String[2][rsmd.getColumnCount()+1];
        	String str="";
        	
        	getAllName[0][rsmd.getColumnCount()]="end";
        	getAllName[1][rsmd.getColumnCount()]="end";
        	
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getAllName[0][i]=getSelect[0][i];
        		getAllName[1][i]="NA";
        	}
        	idmax++;
        	while(true) {
        		str=(String) JOptionPane.showInputDialog(null, "請輸入插入資料\n",
        				"插入資料",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        				getAllName[0],getAllName[0][0]);        		
        		if(str==getAllName[0][0]) {
        			getAllName[1][0]=Integer.toString(idmax);
        			JOptionPane.showMessageDialog(null, "新增id="+getAllName[1][0]);		
        		}
        		for(int i=1;i<rsmd.getColumnCount();i++) {
        			if(str==getAllName[0][i]) {
        				getAllName[1][i]=JOptionPane.showInputDialog(null,"請輸入插入資料",str,
        	        			JOptionPane.PLAIN_MESSAGE);
        				break;
        			}
        		}        		
        		if(str==getAllName[0][rsmd.getColumnCount()]) {
        			break;
        		}
        	}
        	
        	String insert="";
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		insert=insert+"?"+",";
        	}
        	insert="values "+"("+insert.substring(0, insert.length()-1)+")";
        	sqlinsert="insert into "+tableName+" "+insert;
        	
        	/*插入資料*/
        	PreparedStatement stmtinsert=conn.prepareStatement(sqlinsert);
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		stmtinsert.setString(i+1,getAllName[1][i]);
        	}
        	int countinsert=stmtinsert.executeUpdate();
        	System.out.println("修改"+countinsert+"筆");
        	
        	insertdatacount=countinsert;
        	
        	conn.close();
        	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (conn != null) {
					if (!conn.isClosed()) {
						conn.close();
					}
				}
			} catch (Exception e2) {
			}
		}		
		return insertdatacount;
	}
	
	public int UpdateData(String tableName) {
		int updateDataCount=0;
		Connection conn=null;
		
		try {
			conn=DriverManager.getConnection(url, user, password);
        	String sql="select * from "+tableName;
        	String sqlUpdate="";
        	System.out.println("連線成功");
        	PreparedStatement stmt=conn.prepareStatement(sql);
        	ResultSet rs=stmt.executeQuery();
        	ResultSetMetaData rsmd=rs.getMetaData();
			        	
        	/*取得欄位數量與欄位名稱*/
        	String getAllName[]=new String[rsmd.getColumnCount()+1];
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getAllName[i]=rsmd.getColumnName(i+1);
        	}
        	getAllName[rsmd.getColumnCount()]="end";
        	
        	/*取得更改條件欄位*/
        	String whereSelect= (String) JOptionPane.showInputDialog(null, "請輸入更改條件欄位",
        			"更改條件欄位",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        			getAllName,getAllName[0]);       	
        	
        	/*取得更改限制條件*/
        	String input=JOptionPane.showInputDialog(null,"請輸入更改條件","更改條件",
        			JOptionPane.PLAIN_MESSAGE);
        	
        	/*取得更改資料欄位*/
        	String getUpdate[][]=new String[2][rsmd.getColumnCount()];
        	String updateData;
        	String selectName="";
        	String str="";
        	int countUpdate=0;
        	
        	while(true) {
        		str=(String) JOptionPane.showInputDialog(null, "請輸入修改欄位\n",
        				"修改欄位",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        				getAllName,getAllName[0]);
        		
        		if(str==getAllName[0]) {
        			JOptionPane.showMessageDialog(null, "不可變動");
        			continue;
        		}
        		
        		if(str==getAllName[rsmd.getColumnCount()]) {
        			break;
        		}
            	updateData=JOptionPane.showInputDialog(null,"請輸入修改資料","修改資料",
            			JOptionPane.PLAIN_MESSAGE);
        		selectName=selectName+"\""+str+"\""+"=?"+",";
        		countUpdate++;
        		getUpdate[0][countUpdate-1]=str;
        		getUpdate[1][countUpdate-1]=updateData;
        	}
        	selectName=selectName.substring(0,selectName.length()-1);    
			
        	sqlUpdate="update "+tableName+" set "+selectName+" where "+whereSelect+"="
    	            +"?";    	
	    	PreparedStatement stmt1=conn.prepareStatement(sqlUpdate);
	    	for(int i=0;i<countUpdate;i++) {
	    		stmt1.setString(i+1, getUpdate[1][i]);
	    	}
	    	stmt1.setString(countUpdate+1, input);        	
	    	int updateDatac=stmt1.executeUpdate();    	
			updateDataCount=updateDatac;
	    	
	    	conn.close();
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (conn != null) {
					if (!conn.isClosed()) {
						conn.close();
					}
				}
			} catch (Exception e2) {
			}
		}		
		return updateDataCount;
	}
	
	public int deleteData(String tableName) {
		int deleteDataCount=0;
		Connection conn=null;
		
		try {
			conn=DriverManager.getConnection(url, user, password);
        	String sql="select * from "+tableName;
        	String sqlDelete="";
        	System.out.println("連線成功");
        	PreparedStatement stmt=conn.prepareStatement(sql);
        	ResultSet rs=stmt.executeQuery();
        	ResultSetMetaData rsmd=rs.getMetaData();
			
        	/*取得欄位數量與欄位名稱*/
        	String getAllName[]=new String[rsmd.getColumnCount()+1];
        	for(int i=0;i<rsmd.getColumnCount();i++) {
        		getAllName[i]=rsmd.getColumnName(i+1);
        	}
        	getAllName[rsmd.getColumnCount()]="end";
        	
        	/*取得刪除條件欄位*/
        	String whereSelect= (String) JOptionPane.showInputDialog(null, "請輸入刪除條件欄位",
        			"刪除條件欄位",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
        			getAllName,getAllName[0]);       	
        	
        	/*取得刪除限制條件*/
        	String input=JOptionPane.showInputDialog(null,"請輸入刪除條件","刪除條件",
        			JOptionPane.PLAIN_MESSAGE);
			
        	sqlDelete="delete from "+tableName+" where "+whereSelect+"="
    	            +"?"; 
	    	System.out.println("sqlUpdate="+sqlDelete); 
	    	
	    	PreparedStatement stmt1=conn.prepareStatement(sqlDelete);
	    	stmt1.setString(1, input);        	
	    	int deleteDatac=stmt1.executeUpdate();
	    	deleteDataCount=deleteDatac;
	    	
	    	conn.close();
        	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (conn != null) {
					if (!conn.isClosed()) {
						conn.close();
					}
				}
			} catch (Exception e2) {
			}
		}		
		return deleteDataCount;	
	}
	
}
	

