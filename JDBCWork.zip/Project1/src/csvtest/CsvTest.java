package csvtest;

import java.io.*;
import java.net.URL;
import java.sql.*;

public class CsvTest {

	public static void main(String[] args) throws IOException {

	    String inputLine;
	    String outputLine;
	    String[] temp = null;
	    
	    int count=0;
	    
		URL ul = new URL("https://data.tainan.gov.tw/dataset/"
				+ "710b46b9-a1d0-4f90-8299-d7bd2cdd3ad4/resource/"
				+ "acb7f912-4bc4-4b59-931a-b4c7b0b2be1d/download/01_schoolopentime.csv");
        
		InputStreamReader in=new InputStreamReader(ul.openStream());
		BufferedReader bin = new BufferedReader(in);
		FileWriter fw=new FileWriter("C:\\Java\\workspace\\Project1\\csvtest\\temp.txt");
		FileReader fr=new FileReader("C:\\Java\\workspace\\Project1\\csvtest\\temp.txt");
		BufferedReader bfr=new BufferedReader(fr);
		
		/*將CSV寫入暫存檔並記錄資料筆數與計算欄數*/
        while ((inputLine = bin.readLine()) != null) {
        	temp=inputLine.split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)");
        	count++;
        	fw.write(inputLine);
        	fw.write("\r\n");
//        	System.out.println(inputLine);
        }
        in.close();
        bin.close();
		fw.close();
//        System.out.println("count="+count);
//        System.out.println("temp"+temp.length);
        
		/*使用2維陣列儲存資料*/
        String data[][]=new String[count][temp.length];
                
        data=new String[count][temp.length];
        for(int i=0;i<count;i++) {
        	outputLine=bfr.readLine();
        	temp=outputLine.split(",(?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)");
//        	System.out.println("temp"+temp.length);
	        for(int j=0;j<temp.length;j++) {
	        	data[i][j]=temp[j];
	        }
        }
               
        fr.close();
        bfr.close();

        for(int i=0;i<count;i++) {
        	System.out.println("count="+i);
        	System.out.println(" index1= "+data[i][0]+" index2= "+data[i][1]+" index3= "+data[i][2]
        			+" index4= "+data[i][3]+" index5= "+data[i][4]+" index6= "+data[i][5]);
        }
	}

}
