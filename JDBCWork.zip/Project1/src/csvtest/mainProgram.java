package csvtest;

import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class mainProgram {
	
	public static void main(String[] args) throws IOException {

	String option[]={"inputFile","selectAll","selectBy","insert","update","delete",
			"outputFile","End"};
	String selectByOut[]= {"Yes","No"};
	String selectAll[][];
	String selectBy[][];
	int insertCount;
	int updateCount;
	int deleteCount;
	
		while(true) {	
			String str=(String) JOptionPane.showInputDialog(null, "請輸入處理方式\n",
				"Option",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
				option,option[0]);
			
			switch(str) {
			
			case "inputFile":
				inOutFunction input=new inOutFunction();
				input.inputFile();
				System.out.println("匯入資料庫完成");
				break;
			
			case "selectAll":
				sqlFunction sqlSelectAll=new sqlFunction();
				selectAll=sqlSelectAll.select("tableName");
				System.out.println();
				System.out.println("資料全部選取完成");
				break;
			
			case "selectBy":
				sqlFunction sqlSelectBy=new sqlFunction();
				selectBy=sqlSelectBy.selectBy("tableName");
				System.out.println();
				System.out.println("篩選資料完成");
				
				String str1=(String) JOptionPane.showInputDialog(null, "是否匯出資料\n",
						"Yes or No",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
						selectByOut,selectByOut[0]);
				
				if(str1=="Yes") {
					
					inOutFunction selectByOutput=new inOutFunction();
					selectByOutput.outputfile(selectBy);
					System.out.println("選取資料匯出完成");
				}
				break;
				
			case "insert":
				sqlFunction sqlInsert=new sqlFunction();
				insertCount=sqlInsert.insertData("tableName");
				System.out.println("插入資料完成共"+insertCount+"筆");
				break;
			
			case "update":
				sqlFunction sqlUpdate=new sqlFunction();
				updateCount=sqlUpdate.UpdateData("tableName");
				System.out.println("修改資料完成共"+updateCount+"筆");
				break;
			
			case "delete":
				sqlFunction sqlDelete=new sqlFunction();
				deleteCount=sqlDelete.deleteData("tableName");
				System.out.println("資料刪除完成共"+deleteCount+"筆");
				break;
			
			case "outputFile":
				inOutFunction output=new inOutFunction();
				output.outputfile();
				System.out.println("資料匯出完成");
				break;
			
			}
			if(str=="End") {
				System.out.println("程式結束");
				break;
			}
		}
	}
}
