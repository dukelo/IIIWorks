package csvtest;

import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class mainProgramV1 {
	
	public static void main(String[] args) throws IOException {

	String option[]={"inputFile","selectAll","selectBy","insert","update","delete",
			"outputFile","End"};
	String selectByOut[]= {"Yes","No"};
	String selectAll[][];
	String selectBy[][];
	int insertCount;
	int updateCount;
	int deleteCount;
	
		while(true) {
			/*輸入處理方式*/
			String str=(String) JOptionPane.showInputDialog(null, "請輸入處理方式\n",
				"Option",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
				option,option[0]);
			
			switch(str) {
			
			case "inputFile":
				String inputf=JOptionPane.showInputDialog("請輸入表格名稱");				
				inOutFunctionV1 input=new inOutFunctionV1();
				input.inputFile(inputf);
				System.out.println("匯入資料庫完成");
				break;
			
			case "selectAll":
				String nameSelectAll=JOptionPane.showInputDialog("請輸入表格名稱");
				sqlFunctionV1 sqlSelectAll=new sqlFunctionV1();
				selectAll=sqlSelectAll.select(nameSelectAll);
				System.out.println();
				System.out.println("資料全部選取完成");
				break;
			
			case "selectBy":
				String nameSelectBy=JOptionPane.showInputDialog("請輸入表格名稱");
				sqlFunctionV1 sqlSelectBy=new sqlFunctionV1();
				selectBy=sqlSelectBy.selectBy(nameSelectBy);
				System.out.println();
				System.out.println("篩選資料完成");
				
				String str1=(String) JOptionPane.showInputDialog(null, "是否匯出資料\n",
						"Yes or No",JOptionPane.PLAIN_MESSAGE,new ImageIcon("icon.png"),
						selectByOut,selectByOut[0]);
				
				if(str1=="Yes") {
					
					inOutFunctionV1 selectByOutput=new inOutFunctionV1();
					selectByOutput.outputfile(selectBy);;;
					System.out.println("選取資料匯出完成");
				}
				break;
				
			case "insert":
				String nameInsert=JOptionPane.showInputDialog("請輸入表格名稱");
				sqlFunctionV1 sqlInsert=new sqlFunctionV1();
				insertCount=sqlInsert.insertData(nameInsert);
				System.out.println("插入資料完成共"+insertCount+"筆");
				break;
			
			case "update":
				String nameUpdate=JOptionPane.showInputDialog("請輸入表格名稱");
				sqlFunctionV1 sqlUpdate=new sqlFunctionV1();
				updateCount=sqlUpdate.UpdateData(nameUpdate);
				System.out.println("修改資料完成共"+updateCount+"筆");
				break;
			
			case "delete":
				String nameDelete=JOptionPane.showInputDialog("請輸入表格名稱");
				sqlFunctionV1 sqlDelete=new sqlFunctionV1();
				deleteCount=sqlDelete.deleteData(nameDelete);
				System.out.println("資料刪除完成共"+deleteCount+"筆");
				break;
			
			case "outputFile":
				String outputf=JOptionPane.showInputDialog("請輸入表格名稱");
				inOutFunctionV1 output=new inOutFunctionV1();
				output.outputfile(outputf);
				System.out.println("資料匯出完成");
				break;
			
			}
			if(str=="End") {
				System.out.println("程式結束");
				break;
			}
		}
	}
}
